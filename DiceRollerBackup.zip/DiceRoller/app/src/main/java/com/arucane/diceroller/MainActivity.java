package com.arucane.diceroller;

import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

import java.util.Arrays;
import java.util.Random;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Haha you thought", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        final Button d20 = findViewById(R.id.d20);
        final Button d6 = findViewById(R.id.d6);
        final Button d8 = findViewById(R.id.d8);
        final Button d10 = findViewById(R.id.d10);
        final Button d12 = findViewById(R.id.d12);
        final Button d4 = findViewById(R.id.d4);

        Button[] dice = {d4, d6, d8, d10, d12, d20};
        for (Button die : dice) {
            die.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // Parse the value of the button and generate a corresponding random number
                    Random rand = new Random();
                    // Parse the die to be rolled
                    TextView text = (TextView) view;
                    int max = Integer.parseInt(text.getText().subSequence(1, text.getText().length()).toString());
                    // Parse the number of rolls - Could add a try/except block to check if NaN is entered
                    String rollsIn = ((TextView)findViewById(R.id.numDice)).getText().toString();
                    int rolls = (rollsIn.length() > 0) ? Integer.valueOf(rollsIn) : 0;
                    if (rolls <= 0) rolls = 1; // No negative numbers now
                    // Parse the modifier
                    String modIn = ((TextView)findViewById(R.id.modifier)).getText().toString();
                    int mod = (modIn.length() > 0) ? Integer.valueOf(modIn) : 0;
                    // Calculate rolls
                    int sum = 0;
                    int[] results = new int[rolls];
                    for (int i = 0; i < rolls; i++) {
                        results[i] = rand.nextInt(max) + 1;
                        sum += results[i];
                    }
                    sum += mod;

                    TextView textView = findViewById(R.id.textView);
                    textView.setText("Results: " + sum);
                    if (rolls > 1 || mod != 0) textView.append("\n" + Arrays.toString(results));
                    if (mod > 0 ) textView.append("+" + mod);
                    else if (mod < 0) textView.append("" + mod);
                }
            });
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
